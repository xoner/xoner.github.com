#!/bin/bash
#
# This file contains common functions and variables used across the installer scripts.
# This .sh is not meant to be used directly, instead you must source it to use its functions.
#
# Author:   David Pascual Rocher
# Email:    david.pascual@kyndryl.com
# Version:  1.0
# Date:     2025-08-21

## Get OS info 
source /etc/os-release
export DISTRO_FAMILY="${ID_LIKE:-$ID}"
export DISTRO="${ID}"
export MAJOR_VERSION="${VERSION_ID%%.*}"

# Bash settings to avoid bash pitfalls.

# Make the script fail, when accessing an unset variable.
# Saves from horrible unintended consequences, with typos in variable names.
set -o nounset

# Make the script stop if any command fails.
set -e

# function to print a fancy message terminal wide.
print_pretty_message_console_wide() {
    local message="$1"
    local width=$(tput cols)
    local padding=$(( ((width - ${#message}) / 2) -2 ))
    echo ""
    printf '%*s\n' "$(tput cols)" '' | tr ' ' '#'
    printf "# %${padding}s%s%${padding}s #\n" "" "$message" ""
    printf '%*s\n' "$(tput cols)" '' | tr ' ' '#'
    echo ""
}

package_is_installed() {
    package="${1}"

    if [[ "${DISTRO_FAMILY}" == *"fedora"* ]]; then
        rpm -q "${package}" &>/dev/null
    elif [[ "${DISTRO_FAMILYT}" == "debian" ]]; then
        dpkg -s "${package}" &>/dev/null
    else
        # Distro is not supported
        return 1
    fi
}
