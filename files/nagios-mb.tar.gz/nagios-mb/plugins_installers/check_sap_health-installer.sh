#!/bin/bash
# 
# This script installs the plugin check_nwc_health and the prerequisites needed to run it.
#
# Author:   David Pascual Rocher
# Email:    david.pascual@kyndryl.com
# Version:  1.0
# Date:     2025-08-21

# Import common variables and functions
source ./utils.sh

pkg_mgr="dnf"
# Check if we are executing this script in a rhel based distro.
if [[ "${DISTRO_FAMILY}" == *"fedora"* ]]; then
    # Check if distribution is supported only rhel like distros 8+ are supported.
    if (( MAJOR_VERSION < 8 )); then 
        echo "${DISTRO} ${MAJOR_VERSION} is not supported, only rhel 8+ like distributions are supported"
        exit 1
    fi

    # There is no distinction between rhel derivated distros. They are supposed to provide all the 
    # Packages needed to compile and make work this plugin.

    # Install prerequisites.
    print_pretty_message_console_wide "Installing prerequisites"

    "${pkg_mgr}" install -y perl-JSON perl-File-Slurp perl-Date-Manip perl-JSON-XS

    # Install SAP perl libraries and sdk.
    print_pretty_message_console_wide "Install SAP Perl SDK and libraries"

    # Install SDK
    tar xvf ./plugins/check_sap_health_prerequisites/nwrfcsdk.tar.gz 
    sap_dir="/usr/sap"
    if [[ ! -d "${sap_dir}" ]]; then
        mkdir "${sap_dir}"
    fi
    mv nwrfcsdk "${sap_dir}"

    set +u
    sap_sdk_path="/usr/sap/nwrfcsdk/lib"
    if [[ -z "${LD_LIBRARY_PATH}" ]]; then
        export LD_LIBRARY_PATH="${sap_sdk_path}"
    else
        export LD_LIBRARY_PATH="${LD_LIBRARY_PATH}:${sap_sdk_path}"
    fi
    set -u

    # Install SAP libraries
    # save current working directory since we must enter sap library source code directory to compile it
    CWD="$(pwd)"
    tar xvf ./plugins/check_sap_health_prerequisites/sapnwrfc-0.37.tar.gz
    cd sapnwrfc-0.37
    perl Makefile.PL
    make
    make install
    cd "${CWD}"

    # Add SDK libraries to system.
    echo /usr/sap/nwrfcsdk/lib >> /etc/ld.so.conf
    /sbin/ldconfig

    # Extract, compile and install plugin.
    print_pretty_message_console_wide "Compile and install plugin"
    # save current working directory since we must enter plugin source code directory to compile it
    CWD="$(pwd)"
    tar xvf ./plugins/check_sap_health-3.1.0.1.tar.gz
    cd check_sap_health-3.1.0.1
    ./configure
    make all
    make install


    print_pretty_message_console_wide "Installation compplete"

    cd "${CWD}"
    rm -rf check_sap_health-3.1.0.1    
else
    # Any other distro than rhel family is not supported by now.
    echo "Currently ${DISTRO_FAMILY} derived linux distributions are not supported."
    exit 1
fi