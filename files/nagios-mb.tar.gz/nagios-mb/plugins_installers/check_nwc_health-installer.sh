#!/bin/bash
# 
# This script installs the plugin check_nwc_health and the prerequisites needed to run it.
#
# Author:   David Pascual Rocher
# Email:    david.pascual@kyndryl.com
# Version:  1.0
# Date:     2025-08-21

# Import common variables and functions
source ./utils.sh

pkg_mgr="dnf"
# Check if we are executing this script in a rhel based distro.
if [[ "${DISTRO_FAMILY}" == *"fedora"* ]]; then
    # Check if distribution is supported only rhel like distros 8+ are supported.
    if (( MAJOR_VERSION < 8 )); then 
        echo "${DISTRO} ${MAJOR_VERSION} is not supported, only rhel 8+ like distributions are supported"
        exit 1
    fi

    # There is no distinction between rhel derivated distros. They are supposed to provide all the 
    # Packages needed to compile and make work this plugin.

    # Install prerequisites.
    print_pretty_message_console_wide "Installing prerequisites"

    "${pkg_mgr}" install -y perl-JSON perl-File-Slurp perl-Net-SNMP

    # Extract, compile and install plugin.
    print_pretty_message_console_wide "Compile and install plugin"
    # save current working directory since we must enter plugin source code directory to compile it
    CWD="$(pwd)"
    tar xvf ./plugins/check_nwc_health-9.1.tar.gz
    cd check_nwc_health-9.1
    ./configure
    make all
    make install


    print_pretty_message_console_wide "Installation compplete"

    cd "${CWD}"
    rm -rf check_nwc_health-9.1/

    
else
    # Any other distro than rhel family is not supported by now.
    echo "Currently ${DISTRO_FAMILY} derived linux distributions are not supported."
    exit 1
fi