#!/bin/bash
# 
# This script installs the plugin check_oracle_health and the prerequisites needed to run it.
#
# Author:   David Pascual Rocher
# Email:    david.pascual@kyndryl.com
# Version:  1.0
# Date:     2025-08-21

# Import common variables and functions
source ./utils.sh

pkg_mgr="dnf"
# Check if we are executing this script in a rhel based distro.
if [[ "${DISTRO_FAMILY}" == *"fedora"* ]]; then
    # Check if distribution is supported only rhel like distros 8+ are supported.
    if (( MAJOR_VERSION < 8 )); then 
        echo "${DISTRO} ${MAJOR_VERSION} is not supported, only rhel 8+ like distributions are supported"
        exit 1
    fi

    # Check if we are running in a oracle linux distro.
    if [[ "${DISTRO}" == "ol" || "${DISTRO}" == "oracle" ]]; then
        # Install prerequisites.
        print_pretty_message_console_wide "Installing prerequisites"

        "${pkg_mgr}" install -y freetds-devel

        # Define sysbase environment variable, don't know exactly why but it's required to work
        export SYBASE="/usr"

    elif [[ "${DISTRO}" == "rhel" ]]; then
        echo "${DISTRO} is not currently supported, but it will be in the near future. Stay tunned or ask me to add support for it."
        exit 1
    else
        echo "${DISTRO} is not currently supported, maybe it will be in the near future."
        exit 1
    fi
else
    # Any other distro than rhel family is not supported by now.
    echo "Currently ${DISTRO_FAMILY} derived linux distributions are not supported."
    exit 1
fi