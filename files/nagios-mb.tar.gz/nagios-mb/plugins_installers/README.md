This repository contains bash scripts to install prerequisites, compile and install some common and useful nagios plugins like the ones developed by [Consol](https://omd.consol.de/) (kudos for them).


To dowwnload some specific plugin version you can download them from https://labs.consol.de/assets/downloads/nagios/ and modify concrete installation script to point to the specific tar.gz archive of the plugin.

In any case in the folder `labs.consol.de/assets/downloads/nagios` of this repository there is a copy of the plugins hosted in that page in case this url goes down.