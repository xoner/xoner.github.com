#!/bin/bash
# 
# This script installs the plugin check_oracle_health and the prerequisites needed to run it.
#
# Author:   David Pascual Rocher
# Email:    david.pascual@kyndryl.com
# Version:  1.0
# Date:     2025-08-21

# Import common variables and functions
source ./utils.sh

pkg_mgr="dnf"
# Check if we are executing this script in a rhel based distro.
if [[ "${DISTRO_FAMILY}" == *"fedora"* ]]; then
    # Check if distribution is supported only rhel like distros 8+ are supported.
    if (( MAJOR_VERSION < 8 )); then 
        echo "${DISTRO} ${MAJOR_VERSION} is not supported, only rhel 8+ like distributions are supported"
        exit 1
    fi

    # Check if we are running in a oracle linux distro.
    if [[ "${DISTRO}" == "ol" || "${DISTRO}" == "oracle" ]]; then
        print_pretty_message_console_wide "Enabling instantclient ol repos."
        dnf install -y "oracle-instantclient-release-el${MAJOR_VERSION}"
        dnf makecache
        
        # Install prerequisites to compile and install check_oracle_health and DBD::Oracle perl module (needed by the plugin).
        DNF_PREREQUISITES=()
        DNF_PREREQUISITES+=(${pkg_mgr} install -y)
        DNF_PREREQUISITES+=(oracle-instantclient19.28-sqlplus oracle-instantclient19.28-jdbc oracle-instantclient19.28-devel oracle-instantclient19.28-basic libaio perl-DBI libnsl perl-App-cpanminus perl-Test-NoWarnings)

        # OS packages installation.
        # Allow commands to fail temporally
        print_pretty_message_console_wide "Installing required packages"
        "${DNF_PREREQUISITES[@]}"


        # Perl DBD:Oracle module installation
        print_pretty_message_console_wide "Installing perl DBD:Oracle module."
        cpanm DBD::Oracle
        CPAN_RETCODE=$?

        if (( CPAN_RETCODE > 0)); then
            echo "There was some errors installing DBD:Oracle moule. Check cpan output above."
            exit 1
        fi

        # check_oracle_health plugin installation
        print_pretty_message_console_wide "Installing check_oracle_health plugin."
        # save current directory since we are going to enter plugin source code directory and compile it.
        CWD="$(pwd)"
        # Enable script exit on execution fail again.
        set -e

        # Extract plugin source code, compile and instal it.
        tar xvf ./plugins/check_oracle_health-3.3.3.2.tar.gz
        cd check_oracle_health-3.3.3.2
        ./configure
        make all
        make install

        # Since it wen all ok. report it and return to the previous directory.
        print_pretty_message_console_wide "Plugin check_oracle_health installed correctly."
        cd "${CWD}"
        # cleanup plugin source code.
        rm -rf check_oracle_health-3.3.3.2/

    elif [[ "${DISTRO}" == "rhel" ]]; then
        echo "${DISTRO} is not currently supported, but it will be in the near future. Stay tunned or ask me to add support for it."
        exit 1
    else
        echo "${DISTRO} is not currently supported, maybe it will be in the near future."
        exit 1
    fi
else
    # Any other distro than rhel family is not supported by now.
    echo "Currently ${DISTRO_FAMILY} derived linux distributions are not supported."
    exit 1
fi