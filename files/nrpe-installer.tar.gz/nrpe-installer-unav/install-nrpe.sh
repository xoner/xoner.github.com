#!/bin/bash

# This script installs NRPE and the necessary plugins on a Linux system.
# This script only supports RHEL 8+ (and derivates) distributions

readonly NRPE_USER="nrpe"
readonly NAGIOS_PLUGINS_DIR="/usr/local/nagios"

# funtion to print a fancy message terminal wide.
print_pretty_message_console_wide() {
    local message="$1"
    local width=$(tput cols)
    local padding=$(( ((width - ${#message}) / 2) -2 ))
    echo ""
    printf '%*s\n' "$(tput cols)" '' | tr ' ' '#'
    printf "# %${padding}s%s%${padding}s #\n" "" "$message" ""
    printf '%*s\n' "$(tput cols)" '' | tr ' ' '#'
    echo ""
}



# Check if script is running under root
if [[ $EUID -ne 0 ]]; then
    print_pretty_message_console_wide "This script must be run as root"
    exit 1
fi

# Check OS Version
if [[ -f "/etc/os-release" ]]; then
    readonly OS_VERSION="$(grep VERSION_ID /etc/os-release| cut -d '=' -f 2| sed 's/"//g')"
else
    echo "Unsupported OS version"
    exit 1
fi

# If os-release does not have 
if [[ -s "${OS_VERSION}" ]]; then
    echo "Unsupported OS version"
    exit 1
fi

# install pre-requisites 
print_pretty_message_console_wide "Installing pre-requisites"
dnf install -y gcc make gcc-c++ openssl-devel

# add nrpe user if it does not exists
print_pretty_message_console_wide "Checking if user ${NRPE_USER} exists"
if ! id -u "${NRPE_USER}" &>/dev/null; then
    print_pretty_message_console_wide "Creating user ${NRPE_USER}"
    useradd -d "${NAGIOS_PLUGINS_DIR}" -m -r "${NRPE_USER}"
else
    print_pretty_message_console_wide "User ${NRPE_USER} already exists"
fi


# Untar nagios plugins
print_pretty_message_console_wide "Untar nagios-plugins"
tar xf nagios-plugins-2.4.12.tar.gz

# Configure and install nagios plugins
print_pretty_message_console_wide "Configure and install nagios plugins"
cd nagios-plugins-2.4.12
./configure --with-nagios-user="${NRPE_USER}" --with-nagios-group="${NRPE_USER}"
make
make install
cd ..

# change ownership of nagios plugins to nrpe user
print_pretty_message_console_wide "Changing ownership of ${NAGIOS_PLUGINS_DIR} to ${NRPE_USER}"
chown -R "${NRPE_USER}":"${NRPE_USER}" "${NAGIOS_PLUGINS_DIR}"

# Untar nrpe.
print_pretty_message_console_wide "Untar nrpe"
tar xf nrpe-4.1.3.tar.gz
cd nrpe-4.1.3

# Create nagios config dir.
print_pretty_message_console_wide "Creating nagios config directory"
mkdir -p /etc/nagios

# Configure and compile nrpe.
print_pretty_message_console_wide "Configuring and compiling nrpe"
./configure --with-nrpe-user="${NRPE_USER}" \
    --with-nrpe-group="${NRPE_USER}" \
    --with-nagios-user="${NRPE_USER}" \
    --with-nagios-group="${NRPE_USER}" \
    --sysconfdir=/etc/nagios

make all
make install
make install-config
make install-init
cd ..

# Remove source files
print_pretty_message_console_wide "Removing source files"
rm -rf nagios-plugins-2.4.12
rm -rf nrpe-4.1.0







